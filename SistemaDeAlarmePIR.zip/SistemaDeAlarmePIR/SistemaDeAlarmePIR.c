#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pwm.h"

#define PIR 18
#define RED 13
int cont = 0;
#define BUZZER1_PIN 10  // Pino do primeiro buzzer
#define BUZZER2_PIN 21  // Pino do segundo buzzer
#define NOTE_C5 523     // Frequência da nota C5 em Hz

void play_note(uint buzzer_pin, uint frequency) {
    gpio_set_function(buzzer_pin, GPIO_FUNC_PWM);
    uint slice_num = pwm_gpio_to_slice_num(buzzer_pin);
    
    uint clkdiv = 4; // Define um divisor de clock
    uint wrap = 125000000 / (clkdiv * frequency);
    pwm_set_wrap(slice_num, wrap);
    pwm_set_clkdiv(slice_num, clkdiv);
    pwm_set_chan_level(slice_num, pwm_gpio_to_channel(buzzer_pin), wrap / 2);
    pwm_set_enabled(slice_num, true);
}

void stop_buzzer(uint buzzer_pin) {
    uint slice_num = pwm_gpio_to_slice_num(buzzer_pin);
    pwm_set_enabled(slice_num, false);
}

int main()
{
    stdio_init_all();
    gpio_init(PIR);
    gpio_set_dir(PIR, GPIO_IN);
    
    gpio_init(BUZZER1_PIN);
    gpio_set_dir(BUZZER1_PIN, GPIO_OUT);
    gpio_put(BUZZER1_PIN, 0);
    
    gpio_init(BUZZER2_PIN);
    gpio_set_dir(BUZZER2_PIN, GPIO_OUT);
    gpio_put(BUZZER2_PIN, 0);

    gpio_init(RED);
    gpio_set_dir(RED, GPIO_OUT);
    gpio_put(RED, 0);

    while (true) {
        if(gpio_get(PIR) == 1){
              printf("1");
              for (int i = 0; i < 10; i++) {
                  gpio_put(RED, 1);
                  play_note(BUZZER1_PIN, NOTE_C5);
                  play_note(BUZZER2_PIN, NOTE_C5);
                  sleep_ms(100);
                  gpio_put(RED, 0);
                  stop_buzzer(BUZZER1_PIN);
                  stop_buzzer(BUZZER2_PIN);
                  sleep_ms(100);
              }
        } else {
            printf("0");
            gpio_put(RED, 0);
            stop_buzzer(BUZZER1_PIN);
            stop_buzzer(BUZZER2_PIN);
        }
        sleep_ms(10);
    }
}
